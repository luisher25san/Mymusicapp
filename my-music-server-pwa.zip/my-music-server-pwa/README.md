# My Music Server PWA

PWA oscura para navegar y reproducir la biblioteca de **DroidServe** desde otros dispositivos.

## Compatibilidad confirmada con DroidServe

La integración utiliza los endpoints documentados del proyecto:
- `GET /api/info`
- `GET /api/music` → `{ "albums": [{ "path", "name", "cover", "songs": [{ "name", "url", "thumbUrl" }] }] }`
- `GET /thumb/...` para miniaturas/carátulas
- URLs de audio relativas servidas por DroidServe con soporte de Range.

DroidServe genera una miniatura para cada archivo de audio y permite carátula de carpeta (cover/folder/front/albumart/album). La aplicación usa esas URLs; si no hay imagen disponible, muestra la portada genérica.

## Publicar

1. Descomprime el ZIP.
2. Sube el contenido completo de esta carpeta a un hosting estático HTTPS (GitHub Pages, Netlify, Vercel o similar).
3. Abre la URL HTTPS en Chrome y elige **Instalar aplicación** / **Añadir a pantalla de inicio**.
4. Abre Configurar servidor e introduce la dirección de DroidServe.

## Conectar con Xiaomi

1. Instala y abre DroidServe en el Xiaomi.
2. Selecciona la carpeta raíz `Music` y pulsa Start Server.
3. En la PWA introduce la URL mostrada, por ejemplo `http://192.168.1.25:8080`.
4. En la misma red Wi-Fi, prueba conexión.

### Importante: HTTPS y acceso remoto

Los navegadores bloquean solicitudes desde una PWA HTTPS hacia una API HTTP por mixed content. Por eso, aunque la PWA esté publicada, **no funcionará contra la URL HTTP directa de DroidServe desde un hosting HTTPS**. Para uso real remoto, coloca delante de DroidServe un proxy HTTPS seguro (por ejemplo, un reverse proxy accesible mediante tu red privada Tailscale) y configura en la PWA esa URL HTTPS. No expongas el puerto HTTP de DroidServe directamente a Internet.

DroidServe documenta CORS `Access-Control-Allow-Origin: *` y auth opcional. Si activas contraseña, el navegador puede solicitar autenticación HTTP Basic. Esta versión permite guardar usuario; la contraseña se mantiene solo en memoria durante la sesión y se vuelve a pedir al recargar si es necesaria.

## Alcance actual

- Interfaz responsive, modo oscuro.
- Inicio, álbumes, canciones y favoritos.
- Búsqueda local.
- Reproductor con play/pause, anterior/siguiente, aleatorio, repetir, seek y volumen.
- Miniaturas de DroidServe y fallback.
- Manifest, service worker y modo instalable.
- Favoritos persistidos en el navegador.

## Notas

- El reproductor depende de los formatos que soporte el navegador. MP3 y AAC suelen funcionar ampliamente; FLAC depende del navegador/dispositivo.
- La PWA cachea su propia interfaz, no la biblioteca ni los archivos de audio.
- El servidor Xiaomi debe permanecer encendido y accesible mientras reproduces.
- La contraseña no se guarda en localStorage.
